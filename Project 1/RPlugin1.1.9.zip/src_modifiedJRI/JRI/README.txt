This JRI is from rJava and has some methods made public that
aren't public in the original JRI.
